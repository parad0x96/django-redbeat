from django.contrib import admin

from django_redbeat.models import PeriodicTasksEntry

# Register your models here.

admin.site.register(PeriodicTasksEntry)
